#!/usr/bin/env python3
"""Sincroniza el registro de participantes SCT Inst del EPC.

Descarga el CSV oficial, lo valida y genera:
  data/participants.json  lista actual (la lee la web)
  data/changes.json       histórico de altas y bajas entre sincronizaciones
  data/status.json        fecha de la última comprobación correcta (no se versiona)

Si la descarga falla o el CSV parece incompleto, NO toca los datos y sale con
código 1: la web sigue mostrando la última lista buena y GitHub avisa por email.

Uso:
  python scripts/sync_epc.py                 # descarga del EPC
  python scripts/sync_epc.py --file x.csv    # usa un CSV local (pruebas)
Solo usa la librería estándar de Python 3.9+.
"""
import argparse
import csv
import io
import json
import os
import re
import sys
import time
import urllib.request
from datetime import date, datetime, timezone

EPC_URL = "https://www.europeanpaymentscouncil.eu/sites/default/files/participants_export/sct_inst/sct_inst.csv"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "data")
PARTICIPANTS = os.path.join(DATA_DIR, "participants.json")
CHANGES = os.path.join(DATA_DIR, "changes.json")
STATUS = os.path.join(DATA_DIR, "status.json")  # no se versiona: solo va en el despliegue

MIN_ROWS = 1500          # el registro real tiene ~2.800; menos indica un fichero roto
MAX_DROP_RATIO = 0.15    # si desaparece más del 15 % de golpe, algo va mal: no publicar
KEEP_CHANGES = 104       # ~2 años de sincronizaciones con cambios

BIC_RE = re.compile(r"^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$")


def download(url: str, attempts: int = 4) -> bytes:
    last = None
    for i in range(attempts):
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (compatible; sepa-instant-reachability/1.0)",
                "Accept": "text/csv,*/*",
            })
            with urllib.request.urlopen(req, timeout=60) as r:
                body = r.read()
            if len(body) < 50_000:
                raise ValueError(f"respuesta demasiado pequeña ({len(body)} bytes)")
            return body
        except Exception as e:  # noqa: BLE001
            last = e
            print(f"Intento {i + 1}/{attempts} fallido: {e}", file=sys.stderr)
            time.sleep(10 * (i + 1))
    raise RuntimeError(f"No se pudo descargar el CSV del EPC: {last}")


def decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    raise ValueError("codificación desconocida")


def to_iso(value: str) -> str:
    v = (value or "").strip()
    if not v:
        return ""
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", v)
    if m:
        return f"{m[1]}-{m[2]}-{m[3]}"
    m = re.match(r"^(\d{1,2})[/.](\d{1,2})[/.](\d{4})", v)
    if m:
        return f"{m[3]}-{int(m[2]):02d}-{int(m[1]):02d}"
    return v


def norm(h: str) -> str:
    return re.sub(r"[^a-z]", "", h.lower())


def parse(text: str, today: str) -> list:
    first = text.splitlines()[0] if text else ""
    delim = ";" if first.count(";") > first.count(",") else ","
    reader = csv.reader(io.StringIO(text), delimiter=delim)
    header = [norm(h) for h in next(reader)]

    def col(names, fallback):
        for n in names:
            if n in header:
                return header.index(n)
        return fallback

    if "bic" not in header and "participantname" not in header:
        raise ValueError(f"cabecera inesperada: {header}")
    i_country = col(["country"], 0)
    i_name = col(["participantname", "name"], 1)
    i_city = col(["city"], 3)
    i_bic = col(["bic"], 4)
    i_ready = col(["readinessdate"], 5)
    i_leave = col(["schemeleavingdate"], 6)

    rows = {}
    for r in reader:
        if not r or len(r) <= max(i_country, i_bic):
            continue
        bic = re.sub(r"\s", "", r[i_bic]).upper()
        country = r[i_country].strip().upper()
        if not country or not BIC_RE.match(bic):
            continue
        leave = to_iso(r[i_leave]) if i_leave < len(r) else ""
        if leave and leave <= today:
            continue  # ya ha salido del esquema
        rows[bic] = {
            "country": country,
            "name": r[i_name].strip() if i_name < len(r) else "",
            "city": r[i_city].strip() if i_city < len(r) else "",
            "bic": bic,
            "since": to_iso(r[i_ready]) if i_ready < len(r) else "",
        }
    return sorted(rows.values(), key=lambda p: (p["country"], p["name"].upper(), p["bic"]))


def load(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default


def write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", help="CSV local en lugar de descargar")
    args = ap.parse_args()

    today = date.today().isoformat()
    try:
        raw = open(args.file, "rb").read() if args.file else download(EPC_URL)
        rows = parse(decode(raw), today)
    except Exception as e:  # noqa: BLE001
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    if len(rows) < MIN_ROWS:
        print(f"ERROR: solo {len(rows)} participantes (mínimo {MIN_ROWS}). No se actualiza.", file=sys.stderr)
        return 1

    os.makedirs(DATA_DIR, exist_ok=True)
    prev = load(PARTICIPANTS, {"rows": []})
    prev_rows = {p["bic"]: p for p in prev.get("rows", [])}
    new_rows = {p["bic"]: p for p in rows}

    removed = [prev_rows[b] for b in prev_rows if b not in new_rows]
    added = [new_rows[b] for b in new_rows if b not in prev_rows]
    if prev_rows and len(removed) > MAX_DROP_RATIO * len(prev_rows):
        print(f"ERROR: desaparecerían {len(removed)} de {len(prev_rows)} participantes. "
              "Parece un fichero incompleto; no se actualiza.", file=sys.stderr)
        return 1

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    changed = bool(added or removed or not prev_rows or prev.get("rows") != rows)
    if changed:
        write_json(PARTICIPANTS, {
            "source": "EPC SCT Inst Register of Participants",
            "updated": now,
            "count": len(rows),
            "rows": rows,
        })
    write_json(STATUS, {"checked": now, "count": len(rows)})

    if prev_rows and (added or removed):
        changes = load(CHANGES, [])
        changes.insert(0, {"date": today, "added": added, "removed": removed})
        write_json(CHANGES, changes[:KEEP_CHANGES])
    elif not os.path.exists(CHANGES):
        write_json(CHANGES, [])

    print(f"OK: {len(rows)} participantes · +{len(added)} altas · -{len(removed)} bajas")
    return 0


if __name__ == "__main__":
    sys.exit(main())
