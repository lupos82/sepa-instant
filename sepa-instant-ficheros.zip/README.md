# SEPA Instant Reachability · Cryptopocket

Web pública para que los clientes comprueben si el banco de un beneficiario acepta transferencias SEPA Instant.

Los datos salen del registro oficial de participantes SCT Inst del European Payments Council (EPC). Se actualizan solos cada día, sin que nadie tenga que descargar ni subir ficheros.

## Cómo funciona

```
GitHub Actions (cada día, 05:17 UTC)
  └─ sync_epc.py
       ├─ descarga sct_inst.csv del EPC
       ├─ valida el fichero (mínimo 1.500 entidades; nunca borra más del 15 % de golpe)
       ├─ guarda participants.json y el histórico de altas/bajas en changes.json
       └─ si algo falla, NO toca los datos y GitHub te avisa por email
  └─ publica la web en GitHub Pages
```

Los clientes solo necesitan el enlace. La web funciona en móvil, en español e inglés, y en modo claro y oscuro.

**Qué pueden hacer los clientes:**
- **Buscar por BIC:** resultado exacto. Si el BIC es de una sucursal, comprueba también la oficina principal.
- **Buscar por IBAN:** valida los dígitos de control e indica el país. El IBAN no contiene el BIC, así que les pide buscar el banco por BIC o por nombre.
- **Buscar por nombre de banco.**
- **Ver por país:** todas las entidades adheridas de cada país.
- **Novedades:** altas y bajas detectadas, y adhesiones recientes.
- **Enlazar una búsqueda directa:** por ejemplo `…/?q=UBSBCHZZXXX`.

## Puesta en marcha (una sola vez, unos 10 minutos)

### 1. Crear el repositorio
1. Entra en https://github.com/new. Si queréis que la URL lleve el nombre de la empresa, créalo dentro de la organización de Cryptopocket.
2. **Repository name:** `sepa-instant` (el nombre forma parte de la URL).
3. Marca **Public**. GitHub Pages es gratis en repos públicos, y los datos son públicos de todas formas.
4. No marques ninguna casilla de README, .gitignore ni licencia. Pulsa **Create repository**.

### 2. Subir los ficheros
1. En la página del repo vacío, pulsa **uploading an existing file**.
2. Descomprime el ZIP y arrastra **todo su contenido**, incluida la carpeta oculta `.github`.
   - En Mac, pulsa `Cmd + Shift + .` en el Finder para ver las carpetas ocultas.
3. Pulsa **Commit changes**.

> Comprueba que existe el fichero `.github/workflows/sync-and-deploy.yml` en el repo. Sin él no hay actualización automática.

### 3. Activar GitHub Pages
1. En el repo, ve a **Settings → Pages**.
2. En **Build and deployment → Source**, elige **GitHub Actions**.

### 4. Activar la escritura del robot
1. Ve a **Settings → Actions → General**.
2. En **Workflow permissions**, marca **Read and write permissions** y pulsa **Save**.

### 5. Primera sincronización
1. Ve a la pestaña **Actions → Sincronizar EPC y publicar**.
2. Pulsa **Run workflow** y después el botón verde **Run workflow**.
3. Tarda 1–2 minutos. Cuando aparezca el tic verde, la web está publicada en:
   `https://<usuario-u-organización>.github.io/sepa-instant/`

Ese es el enlace que enviáis a los clientes.

### 6. (Opcional) Dominio propio, p. ej. `sepa.cryptopocket.io`
1. En vuestro proveedor de DNS, crea un registro **CNAME** que apunte `sepa` a `<usuario-u-organización>.github.io`.
2. En **Settings → Pages → Custom domain**, escribe `sepa.cryptopocket.io` y guarda.
3. Cuando el certificado esté listo, marca **Enforce HTTPS**.

## Mantenimiento

- **No hay nada que hacer día a día.** La tarjeta «Datos comprobados» muestra a clientes y equipo cuándo fue la última comprobación. Se pone en naranja si pasan más de 3 días.
- **Si falla una sincronización,** GitHub envía un email al dueño del repo y la web sigue con la última lista buena. Suele deberse a que el EPC no respondió, y se corrige solo al día siguiente.
- **Actualizar a mano:** en **Actions → Run workflow**.
- **Cambiar textos o diseño:** edita `index.html` en GitHub y guarda; se republica solo.
- **Inactividad:** GitHub pausa las tareas programadas de un repo tras 60 días sin cambios. Como el EPC publica altas cada semana, el robot hace commits y eso no debería pasar. Si un día ves la tarea pausada, pulsa **Enable workflow** en Actions.

## Probar en local

```bash
python3 sync_epc.py              # descarga del EPC
python3 sync_epc.py --file x.csv # o con un CSV ya descargado
python3 -m http.server 8000              # abre http://localhost:8000
```

## Límites

- El registro del EPC indica qué entidades están adheridas al esquema SCT Inst. No muestra por qué cámara de compensación se llega a cada una. Para enrutar pagos en producción, la fuente definitiva es el servicio de alcanzabilidad de vuestro proveedor SEPA.
- En la zona euro, los bancos están obligados a recibir transferencias inmediatas desde el 9 de enero de 2025. Las entidades de pago y de dinero electrónico lo están desde el 9 de abril de 2027. La web lo indica cuando un banco de la zona euro no figura en el registro.
